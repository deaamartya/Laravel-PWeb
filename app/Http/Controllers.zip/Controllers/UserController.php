<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $user = DB::table('user')->get();
        $userss = User::all();
        return view('user/display', ['userss' => $userss]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('user/create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // $userss = new User;
        // $userss->user_id = $request->user_id;
        // $userss->first_name = $request->first_name;
        // $userss->last_name = $request->last_name;
        // $userss->phone = $request->phone;
        // $userss->email = $request->email;
        // $userss->password = $request->password;
        // $userss->job_status = $request->job_status;
        // $userss->save();
        // session()->flash('success', 'Data Berhasil Di Tambahkan!');
        // return redirect('user/display');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function show(User $user)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $userss = User::where('id', $id)->first();
        return view('user/edit', ['userss' => $userss]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $userss = User::where('id', $id)->update([
            'name' => $request->name,
            'email' => $request->email
            ]);
        session()->flash('warning', 'Data Berhasil Di Update!');
        return redirect('user/display');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $userss = User::where('id', $id);
        $userss->delete();
        session()->flash('danger', 'Data Berhasil Di Hapus!');
        return redirect('user/display');
    }
}
