@extends('layout.header')

@section('judul', 'About')

@section('container')

<link rel="stylesheet" type="text/css" href="/css/about.css">

    <div class="container">
        <div class="row">
            <div class="col-20">
                <h1 class="ab">About</h1>

               
            @yield('container')
                </p>

            </div>
        </div>
    </div>
@endsection