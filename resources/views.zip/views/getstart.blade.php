<!-- <!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Laravel Beta</title> -->
		<!-- <link rel="stylesheet" href="css/register.css"> -->
	<!-- </head>
	<body> -->
		<button href="{{ url('/login') }}">get start</button>
	<!-- </body>
</html> -->