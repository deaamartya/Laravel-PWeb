@extends('layout.header')

@section('judul', 'Data Product')

@section('container')

<link rel="stylesheet" type="text/css" href="/css/form_products.css">

    <div class="container">
        <div class="row">
            <div class="boxdisplay">
                <h1 class="dp">Data Product</h1>
                <a href="/product/create" class="tb">Tambah Product</a>

                @if(session()->has('success'))
                <div class="alert alert-success alert-dismissible">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>{{ session('success') }}</strong>
                </div>
                @endif

                @if(session()->has('warning'))
                <div class="alert alert-warning alert-dismissible">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>{{ session('warning') }}</strong>
                </div>
                @endif

                @if(session()->has('danger'))
                <div class="alert alert-danger alert-dismissible">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>{{ session('danger') }}</strong>
                </div>
                @endif

                <table class="table table-striped table-dark">
                    <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Product_id</th>
                            <th scope="col">Category Id</th>
                            <th scope="col">Product Name</th>
                            <th scope="col">Product Price</th>
                            <th scope="col">Product Stock</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>

                        @foreach( $products as $pd)

                        <tr>
                            <th scope="row">{{ $loop->iteration }}</th>
                            <td>{{ $pd->product_id}}</td>
                            <td>{{ $pd->category_id}}</td>
                            <td>{{ $pd->product_name}}</td>
                            <td>{{ $pd->product_price}}</td>
                            <td>{{ $pd->product_stock}}</td>
                            <td>
                            <a href="/product/edit/{{ $pd->product_id}}" class="btn btn-info m-1">Edit</a>
                            <!-- <a href="/product/hapus/{{ $pd->product_id}}" class="btn btn-danger">Delete</a> -->
                            </td>
                        </tr>

                        @endforeach

                    </tbody>
                </table>
                    </div>
            </div>
        </div>
    </div>
@endsection