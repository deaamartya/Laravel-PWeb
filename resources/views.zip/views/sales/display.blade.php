@extends('layout.header')

@section('judul', 'Data Sales')

@section('container')

<link rel="stylesheet" type="text/css" href="/css/form_saless.css">

    <div class="container">
        <div class="row">
            <div class="boxdisplay">
                <h1 class="ds">Data Sales</h1>

                <a href="/sales/index" class="tb">Tambah Sales</a>
                <!-- <a href="/categori/update" class="btn btn-info my-3">Update Categori</a> -->
                
                <table class="table table-striped table-dark">
                    <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Nota_id</th>
                            <th scope="col">Customer_id</th>
                            <th scope="col">User_id</th>
                            <th scope="col">Nota_date</th>
                            <th scope="col">Total_payment</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>

                        @foreach( $sales as $sl)

                        <tr>
                            <th scope="row">{{ $loop->iteration }}</th>
                            <td>{{ $sl->nota_id}}</td>
                            <td>{{ $sl->customer_id}}</td>
                            <td>{{ $sl->user_id}}</td>
                            <td>{{ $sl->nota_date}}</td>
                            <td>{{ $sl->total_payment}}</td>
                            <td>
                            <a href="/sales/show/{{ $sl->nota_id }}" class="btn btn-info">Detail</a>
                            <a href="/sales/hapus/{{ $sl->nota_id }}" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>

                        @endforeach

                    </tbody>
                </table>
                @if (session('status'))
                    <div class="alert alert-success">
                        {{ session('status') }}
                    </div>
                @endif
            </div>
        </div>
    </div>
@endsection