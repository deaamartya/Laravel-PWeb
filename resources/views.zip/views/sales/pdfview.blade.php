<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Invoice.pdf</title>
</head>
<body>
    <div class="card">
        <div class="card-body">

            <h3 style="text-align:center">
                <b>Detail Transaction</b>
            </h3>
            <br>

            <h5 style="text-align:center" scope="col">Date : {{$sales->nota_date}}</h5>
            <h5 style="text-align:center" scope="col">Nota Id : {{$sales->nota_id}}</h5>
            <br>
            <h5 style="text-align:left" scope="col">User : {{$sales->name}}</h5>
            <h5 style="text-align:left" scope="col">Customer : {{$sales->full_name}}</h5>
                                        
            <table class="table table-bordered table-white">
                <thead class="thead-light">
                    <tr>
                        <th style="text-align:center" scope="col">No</th>
                        <th style="text-align:center" scope="col">Product</th>
                        <th style="text-align:center" scope="col">Quantity</th>
                        <th style="text-align:center" scope="col">Selling Price</th>
                        <th style="text-align:center" scope="col">Discount</th>
                        <th style="text-align:center" scope="col">Total Price</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach( $sales_detail as $sd)
                    <tr>
                        <th style="text-align:center" scope="col">{{ $loop->iteration }}</th>
                        <td style="text-align:center" scope="col">{{ $sd->product_name}}</td>
                        <td style="text-align:center" scope="col">{{ $sd->quantity}} Pcs</td>
                        <td style="text-align:center" scope="col">Rp.{{ $sd->selling_price}}/Pcs</td>
                        <td style="text-align:center" scope="col">Rp.{{ $sd->discount}}</td>
                        <td style="text-align:center" scope="col">Rp.{{ $sd->total_price}}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>

            <br>
            <h4 style="text-align:left" class="text-uppercase" scope="col">Total Payment : Rp. {{$sales->total_payment}},-</h4>
            
        </div>

    </div>
</body>
</html>